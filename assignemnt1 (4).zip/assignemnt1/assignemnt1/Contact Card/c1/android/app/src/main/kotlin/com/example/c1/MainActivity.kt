package com.example.c1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
