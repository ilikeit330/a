package com.example.fm1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
