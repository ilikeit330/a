import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:share_plus/share_plus.dart';

class NewsPreviewApp extends StatelessWidget {
  const NewsPreviewApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'News Article Preview',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
      ),
      home: const NewsPreviewScreen(),
    );
  }
}

class NewsPreviewScreen extends StatelessWidget {
  const NewsPreviewScreen({super.key});

  void _shareArticle(BuildContext context) {
    Share.share(
      'Check out this article: Flutter 3.10 Released with New Features\nhttps://flutter.dev',
      subject: 'Flutter News',
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('News Preview')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Card(
          elevation: 4,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.network(
                    // --- FIX 1: Replaced the broken URL with a functional placeholder ---
                    'https://picsum.photos/600/300', 
                    // -------------------------------------------------------------------
                    height: 180,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    // --- FIX 2: Added errorBuilder for robust error handling ---
                    errorBuilder: (context, error, stackTrace) {
                      return Container(
                        height: 180,
                        width: double.infinity,
                        color: Colors.grey[200],
                        child: Center(
                          child: Icon(
                            Icons.image_not_supported,
                            size: 50,
                            color: Colors.grey[600],
                          ),
                        ),
                      );
                    },
                    // -------------------------------------------------------------------
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  'Flutter 3.10 Released with New Features',
                  style: GoogleFonts.merriweather(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  'Flutter 3.10 introduces enhanced performance, new widgets, and improved DevTools for debugging.',
                  style: GoogleFonts.sourceSans3( 
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Published: Nov 9, 2025 • By Flutter Team',
                  style: GoogleFonts.roboto(
                    fontSize: 14,
                    fontWeight: FontWeight.w300,
                    color: Colors.grey[700],
                  ),
                ),
                const SizedBox(height: 16),
                Align(
                  alignment: Alignment.centerRight,
                  child: ElevatedButton.icon(
                    onPressed: () => _shareArticle(context),
                    icon: const Icon(Icons.share),
                    label: const Text('Share'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}