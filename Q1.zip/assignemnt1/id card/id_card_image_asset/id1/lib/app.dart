import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class StudentIDApp extends StatelessWidget {
  const StudentIDApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Student ID Card',
      theme: ThemeData(
  primarySwatch: Colors.indigo,
  textTheme: TextTheme(
    titleLarge: GoogleFonts.poppins(fontWeight: FontWeight.bold),
    bodyMedium: GoogleFonts.inter(fontWeight: FontWeight.w400),
    titleMedium: GoogleFonts.roboto(fontWeight: FontWeight.w500),
  ),
),

      home: const StudentIDCard(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class StudentIDCard extends StatelessWidget {
  const StudentIDCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Student ID', style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
        centerTitle: true,
      ),
      body: Center(
        child: Card(
          elevation: 3,
          margin: const EdgeInsets.all(5),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: Padding(
            padding: const EdgeInsets.all(5),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CircleAvatar(
                  radius: 40,
                  backgroundImage: AssetImage('assets/student.jpg'), // Add your image in assets
                ),
                const SizedBox(height: 16),
                Text('Mansi Sharma', style: GoogleFonts.poppins(fontSize: 22, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('Flutter Developer', style: GoogleFonts.inter(fontSize: 16, fontWeight: FontWeight.w400)),
                const Divider(height: 30, thickness: 1),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('ID:', style: GoogleFonts.roboto(fontWeight: FontWeight.w500)),
                    Text('20251101', style: GoogleFonts.inter()),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Course:', style: GoogleFonts.roboto(fontWeight: FontWeight.w500)),
                    Text('Flutter Bootcamp', style: GoogleFonts.inter()),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
