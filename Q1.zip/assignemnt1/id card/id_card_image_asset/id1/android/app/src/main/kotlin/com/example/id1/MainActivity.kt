package com.example.id1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
