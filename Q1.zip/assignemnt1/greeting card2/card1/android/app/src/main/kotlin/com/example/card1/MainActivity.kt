package com.example.card1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
